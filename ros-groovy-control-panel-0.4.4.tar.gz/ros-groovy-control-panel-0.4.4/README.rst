SDSM&T RIAS Shared Robotics Systems (SRS) Control Panel
===============================================================================

**brief overview goes here**


Installation Notes
-------------------------------------------------------------------------------
SRS Control Panel has only been tested on Ubuntu 10.04
The required tools to compile the SRS Control Panel are below.

ROS:
  http://www.ros.org/wiki

Qt:
  http://qt.nokia.com
